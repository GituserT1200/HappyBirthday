/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HeaderNav } from './components/HeaderNav';
import { BirthdayHeroCard } from './components/BirthdayHeroCard';
import { AppreciationGiftBox } from './components/AppreciationGiftBox';
import { BirthdayCakeInteractive } from './components/BirthdayCakeInteractive';
import { LuckyWishDrawer } from './components/LuckyWishDrawer';
import { GuestWishBoard } from './components/GuestWishBoard';
import { FloatingParticles } from './components/FloatingParticles';
import { Footer } from './components/Footer';
import { sound } from './utils/soundEffects';

export default function App() {
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);

  const handlePlayMelody = () => {
    if (isPlayingMusic) {
      setIsPlayingMusic(false);
      return;
    }
    setIsPlayingMusic(true);
    sound.playHappyBirthdayMelody(() => {
      setIsPlayingMusic(false);
    });
  };

  const scrollToGift = () => {
    const el = document.getElementById('tri-an');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50/50 via-rose-50/30 to-pink-50/40 text-slate-800 relative selection:bg-pink-200 selection:text-pink-900">
      {/* Floating hearts and ambient background particles */}
      <FloatingParticles />

      {/* Top Bar navigation */}
      <HeaderNav />

      {/* Main Content Area */}
      <main className="relative z-10 space-y-4">
        {/* Section 1: Birthday Card with 3D envelope toggle */}
        <BirthdayHeroCard
          onScrollToGift={scrollToGift}
          onPlayMelody={handlePlayMelody}
          isPlayingMusic={isPlayingMusic}
        />

        {/* Section 2: Secret appreciation gift box with document gratitude letter & 3-year milestones */}
        <AppreciationGiftBox />

        {/* Section 3: Interactive Birthday Cake with candles & melody */}
        <BirthdayCakeInteractive
          onPlayMelody={handlePlayMelody}
          isPlayingMusic={isPlayingMusic}
        />

        {/* Lucky blessing cards drawer */}
        <LuckyWishDrawer />

        {/* Section 4: Guest wish board to send wishes back */}
        <GuestWishBoard />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
