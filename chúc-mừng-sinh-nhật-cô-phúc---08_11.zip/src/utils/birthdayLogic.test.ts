import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateWish,
  formatBirthdayBadge,
  INITIAL_WISHES,
  MEMORY_MILESTONES,
  LUCKY_WISH_CARDS,
} from './birthdayLogic';

test('validateWish detects empty name', () => {
  const result = validateWish('', 'Chúc mừng sinh nhật cô Phúc!');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /tên/i);
});

test('validateWish detects too short name', () => {
  const result = validateWish('A', 'Chúc mừng sinh nhật cô Phúc!');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /2 ký tự/i);
});

test('validateWish detects empty message', () => {
  const result = validateWish('Nam', '   ');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /lời chúc/i);
});

test('validateWish detects short message', () => {
  const result = validateWish('Nam', 'Hi');
  assert.equal(result.isValid, false);
  assert.match(result.error || '', /5 ký tự/i);
});

test('validateWish passes on valid inputs', () => {
  const result = validateWish('Minh Anh', 'Chúc cô Phúc luôn bình an và hạnh phúc!');
  assert.equal(result.isValid, true);
  assert.equal(result.error, undefined);
});

test('formatBirthdayBadge outputs correct Vietnamese date badge', () => {
  assert.equal(formatBirthdayBadge(8, 11), 'Ngày 08 Tháng 11');
  assert.equal(formatBirthdayBadge(15, 5), 'Ngày 15 Tháng 05');
});

test('constants have valid items matching the document requirements', () => {
  assert.ok(INITIAL_WISHES.length >= 3);
  assert.ok(MEMORY_MILESTONES.length === 4);
  assert.ok(LUCKY_WISH_CARDS.length >= 5);
  assert.ok(MEMORY_MILESTONES.some(m => m.title.includes('3 Năm')));
  assert.ok(MEMORY_MILESTONES.some(m => m.title.includes('Tận Tâm')));
});
