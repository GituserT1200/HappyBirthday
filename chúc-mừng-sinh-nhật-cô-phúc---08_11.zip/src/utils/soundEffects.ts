/**
 * Web Audio API synthesizer for delightful, reliable birthday sound effects & melody
 * Zero external audio assets required; works cross-platform and handles audio context unlocking safely.
 */

class SoundManager {
  private ctx: AudioContext | null = null;
  public isMuted: boolean = false;

  private initCtx(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted && this.ctx) {
      this.ctx.suspend();
    } else if (!this.isMuted && this.ctx) {
      this.ctx.resume();
    }
    return this.isMuted;
  }

  // Play a soft kalimba / music box bell tone
  public playTone(freq: number, duration: number, type: OscillatorType = 'sine', gainVal = 0.15) {
    const ctx = this.initCtx();
    if (!ctx) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      gain.gain.setValueAtTime(gainVal, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  // Play Happy Birthday tune notes in a music-box style
  public playHappyBirthdayMelody(onComplete?: () => void) {
    const ctx = this.initCtx();
    if (!ctx) return;

    // Happy birthday notes (in Hz):
    // Happy (G4) birth (G4) day (A4) to (G4) you (C5) ... (B4)
    // Happy (G4) birth (G4) day (A4) to (G4) you (D5) ... (C5)
    // Happy (G4) birth (G4) day (G5) dear Cô Phúc (E5, C5, B4, A4)
    // Happy (F5) birth (F5) day (E5) to (C5) you (D5) ... (C5)
    const notes: { freq: number; duration: number; delay: number }[] = [
      { freq: 392.00, duration: 0.35, delay: 0 },       // Sol
      { freq: 392.00, duration: 0.35, delay: 0.4 },     // Sol
      { freq: 440.00, duration: 0.6,  delay: 0.8 },     // La
      { freq: 392.00, duration: 0.6,  delay: 1.5 },     // Sol
      { freq: 523.25, duration: 0.6,  delay: 2.2 },     // Do
      { freq: 493.88, duration: 1.0,  delay: 2.9 },     // Si

      { freq: 392.00, duration: 0.35, delay: 4.1 },     // Sol
      { freq: 392.00, duration: 0.35, delay: 4.5 },     // Sol
      { freq: 440.00, duration: 0.6,  delay: 4.9 },     // La
      { freq: 392.00, duration: 0.6,  delay: 5.6 },     // Sol
      { freq: 587.33, duration: 0.6,  delay: 6.3 },     // Re
      { freq: 523.25, duration: 1.0,  delay: 7.0 },     // Do

      { freq: 392.00, duration: 0.35, delay: 8.2 },     // Sol
      { freq: 392.00, duration: 0.35, delay: 8.6 },     // Sol
      { freq: 783.99, duration: 0.7,  delay: 9.0 },     // Sol cao
      { freq: 659.25, duration: 0.7,  delay: 9.8 },     // Mi
      { freq: 523.25, duration: 0.6,  delay: 10.6 },    // Do
      { freq: 493.88, duration: 0.6,  delay: 11.3 },    // Si
      { freq: 440.00, duration: 0.9,  delay: 12.0 },    // La

      { freq: 698.46, duration: 0.35, delay: 13.1 },    // Fa
      { freq: 698.46, duration: 0.35, delay: 13.5 },    // Fa
      { freq: 659.25, duration: 0.7,  delay: 13.9 },    // Mi
      { freq: 523.25, duration: 0.6,  delay: 14.7 },    // Do
      { freq: 587.33, duration: 0.7,  delay: 15.4 },    // Re
      { freq: 523.25, duration: 1.4,  delay: 16.2 },    // Do
    ];

    notes.forEach((n) => {
      setTimeout(() => {
        if (!this.isMuted) {
          // Play a warm dual tone (fundamental + harmonic) for music box warmth
          this.playTone(n.freq, n.duration, 'sine', 0.12);
          this.playTone(n.freq * 2, n.duration * 0.7, 'triangle', 0.05);
        }
      }, n.delay * 1000);
    });

    if (onComplete) {
      setTimeout(onComplete, 17800);
    }
  }

  // Pop sound for confetti and gift reveal
  public playPop() {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(450, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch {
      // ignore
    }
  }

  // Magic chime sparkle when opening the gift or card
  public playSparkle() {
    const freqs = [523.25, 659.25, 783.99, 1046.50];
    freqs.forEach((freq, idx) => {
      setTimeout(() => {
        this.playTone(freq, 0.4, 'sine', 0.1);
      }, idx * 75);
    });
  }

  // Breath puff sound for blowing candles
  public playCandleBlow() {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      // Soft noise puff
      const bufferSize = ctx.sampleRate * 0.35;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(400, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.35);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      noise.start();
    } catch {
      // ignore
    }
  }

  // Soft heart tap chime
  public playHeartSound() {
    this.playTone(880, 0.2, 'sine', 0.08);
  }
}

export const sound = new SoundManager();
