/**
 * Pure helper functions and logic for Cô Phúc's Birthday App
 */

export interface WishEntry {
  id: string;
  senderName: string;
  message: string;
  timestamp: number;
  likes: number;
}

export interface MemoryMilestone {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: string;
  tag: string;
}

/**
 * Validates a guest wish input before saving
 */
export function validateWish(senderName: string, message: string): { isValid: boolean; error?: string } {
  const trimmedName = senderName.trim();
  const trimmedMessage = message.trim();

  if (!trimmedName) {
    return { isValid: false, error: 'Vui lòng nhập tên của bạn' };
  }
  if (trimmedName.length < 2) {
    return { isValid: false, error: 'Tên phải có ít nhất 2 ký tự' };
  }
  if (trimmedName.length > 50) {
    return { isValid: false, error: 'Tên không được vượt quá 50 ký tự' };
  }
  if (!trimmedMessage) {
    return { isValid: false, error: 'Vui lòng nhập lời chúc ý nghĩa' };
  }
  if (trimmedMessage.length < 5) {
    return { isValid: false, error: 'Lời chúc phải có ít nhất 5 ký tự' };
  }
  if (trimmedMessage.length > 500) {
    return { isValid: false, error: 'Lời chúc không được dài quá 500 ký tự' };
  }

  return { isValid: true };
}

/**
 * Formats date 8/11 and returns celebratory text
 */
export function formatBirthdayBadge(day = 8, month = 11): string {
  const formattedDay = day < 10 ? `0${day}` : `${day}`;
  const formattedMonth = month < 10 ? `0${month}` : `${month}`;
  return `Ngày ${formattedDay} Tháng ${formattedMonth}`;
}

/**
 * Initial curated wishes for Cô Phúc
 */
export const INITIAL_WISHES: WishEntry[] = [
  {
    id: 'wish-1',
    senderName: 'Học trò thương quý',
    message: 'Chúc cô Phúc bước sang tuổi mới luôn dồi dào sức khỏe, luôn nở nụ cười rạng rỡ và tràn đầy niềm vui bên gia đình yêu thương!',
    timestamp: Date.now() - 3600000 * 5,
    likes: 18,
  },
  {
    id: 'wish-2',
    senderName: 'Tập thể học sinh',
    message: 'Cảm ơn cô vì đã luôn là ngọn hải đăng soi sáng và dìu dắt chúng em trong suốt hơn 3 năm qua. Chúc mừng sinh nhật cô Phúc!',
    timestamp: Date.now() - 3600000 * 12,
    likes: 24,
  },
  {
    id: 'wish-3',
    senderName: 'Một người học trò',
    message: 'Mong mọi điều bình an, may mắn và hạnh phúc nhất sẽ luôn đồng hành cùng cô trong cuộc sống và sự nghiệp trồng người cao quý.',
    timestamp: Date.now() - 3600000 * 24,
    likes: 15,
  },
];

/**
 * 4 memorable milestones derived directly from the user's document
 */
export const MEMORY_MILESTONES: MemoryMilestone[] = [
  {
    id: 'm1',
    title: 'Hơn 3 Năm Đồng Hành & Dìu Dắt',
    subtitle: 'Từng bước trưởng thành',
    description: 'Từ chuyện bài vở, thi cử đến những việc nhỏ nhặt trong cuộc sống thường nhật, cô luôn lắng nghe và hỗ trợ em hết mình.',
    iconName: 'Clock',
    tag: '3+ Năm Gắn Bó',
  },
  {
    id: 'm2',
    title: 'Những Bài Giảng Tận Tâm & Nhiệt Huyết',
    subtitle: 'Tri thức & truyền cảm hứng',
    description: 'Những giờ học không chỉ đầy ắp kiến thức mà còn rực cháy ngọn lửa nhiệt huyết, khơi gợi niềm đam mê và sáng tạo.',
    iconName: 'BookOpen',
    tag: 'Tận Tâm Trồng Người',
  },
  {
    id: 'm3',
    title: 'Những Hoạt Động Lớp Tràn Ngập Tiếng Cười',
    subtitle: 'Kỷ niệm khó phai',
    description: 'Những lần cô cùng cả lớp chung tay làm những điều đặc biệt mà cuộc sống thường ngày không thể đem đến, lưu giữ kỷ niệm tuổi học trò.',
    iconName: 'Smile',
    tag: 'Khoảnh Khắc Đẹp',
  },
  {
    id: 'm4',
    title: 'Những Bài Học Sâu Sắc Về Cuộc Sống',
    subtitle: 'Hành trang tương lai',
    description: 'Không chỉ là kiến thức trong sách vở, cô đã trao cho em những góc nhìn sâu sắc, dạy em cách làm người tử tế và kiên cường.',
    iconName: 'HeartHandshake',
    tag: 'Hành Trang Ý Nghĩa',
  },
];

/**
 * Fortune / Lucky Wish messages when clicking the lucky drawer
 */
export const LUCKY_WISH_CARDS = [
  {
    title: '🌸 Bình An & Sức Khỏe',
    content: 'Chúc cô Phúc mỗi ngày thức dậy đều ngập tràn năng lượng tích cực, tâm hồn thư thái và sức khỏe dồi dào!',
  },
  {
    title: '✨ Gia Đình Hạnh Phúc',
    content: 'Chúc tổ ấm của cô luôn rộn rã tiếng cười, yêu thương đong đầy và mỗi khoảnh khắc bên nhau đều ấm áp.',
  },
  {
    title: '💎 Vạn Sự Như Ý',
    content: 'Chúc mọi dự định, mong ước và mục tiêu của cô trong tuổi mới đều gặt hái thành công rực rỡ.',
  },
  {
    title: '🌷 Luôn Trẻ Trung & Tươi Vui',
    content: 'Chúc cô luôn giữ mãi nụ cười tỏa nắng, nét tươi trẻ và niềm đam mê rực cháy với công việc giảng dạy.',
  },
  {
    title: '🌟 Niềm Vui Đong Đầy',
    content: 'Chúc cô luôn nhận được sự kính trọng, yêu mến từ các thế hệ học trò và những điều ngọt ngào nhất của cuộc sống.',
  },
];
