import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Flame, Wind, RotateCcw, Music, Sparkles } from 'lucide-react';
import { sound } from '../utils/soundEffects';

interface BirthdayCakeInteractiveProps {
  onPlayMelody: () => void;
  isPlayingMusic: boolean;
}

export const BirthdayCakeInteractive: React.FC<BirthdayCakeInteractiveProps> = ({
  onPlayMelody,
  isPlayingMusic,
}) => {
  const [candlesLit, setCandlesLit] = useState(true);
  const [wishMade, setWishMade] = useState(false);

  const handleBlowCandles = () => {
    if (!candlesLit) return;
    sound.playCandleBlow();
    setCandlesLit(false);
    setWishMade(true);

    setTimeout(() => {
      sound.playSparkle();
      confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.6 },
        colors: ['#fbbf24', '#f43f5e', '#ec4899', '#38bdf8', '#a855f7'],
      });
    }, 400);
  };

  const handleRelight = () => {
    sound.playSparkle();
    setCandlesLit(true);
    setWishMade(false);
  };

  return (
    <section id="banh-kem" className="py-16 sm:py-20 px-4 max-w-4xl mx-auto">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 text-sm font-semibold text-amber-700 bg-amber-100/80 px-4 py-1.5 rounded-full mb-3 shadow-xs">
          <Sparkles className="w-4 h-4 text-amber-600" />
          <span>Hoạt Động Tương Tác Vui Vẻ</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
          Chiếc Bánh Kem Sinh Nhật & Thổi Nến Ước Nguyện
        </h2>
        <p className="mt-2 text-slate-600 text-base max-w-lg mx-auto">
          Mời cô Phúc nhắm mắt lại, ước một điều ước thật tuyệt vời và bấm nút thổi nến nhé!
        </p>
      </div>

      <div className="bg-gradient-to-b from-amber-50/80 via-white to-pink-50/70 rounded-3xl p-8 sm:p-12 border border-pink-200/80 shadow-xl max-w-2xl mx-auto text-center relative overflow-hidden">
        {/* Floating musical notes if music is playing */}
        {isPlayingMusic && (
          <div className="absolute top-4 right-6 flex items-center gap-1 text-pink-500 animate-bounce">
            <span className="text-xl">🎵</span>
            <span className="text-sm font-bold">Giai điệu đang vang lên...</span>
          </div>
        )}

        {/* Realistic Delightful Cake Illustration */}
        <div className="relative w-64 h-64 mx-auto my-4 flex flex-col items-center justify-end">
          {/* Candle Flames & Wicks */}
          <div className="flex items-end justify-center gap-8 mb-1 z-20">
            {[0, 1, 2].map((idx) => (
              <div key={idx} className="flex flex-col items-center">
                {/* Flame */}
                {candlesLit ? (
                  <div className="relative cursor-pointer" onClick={handleBlowCandles} title="Nhấn để thổi nến">
                    <div className="w-4 h-6 bg-gradient-to-t from-amber-500 via-yellow-300 to-white rounded-full animate-pulse filter drop-shadow-[0_0_8px_rgba(251,191,36,0.9)] transform -translate-y-1" />
                    <div className="w-2 h-3 bg-white rounded-full absolute top-1 left-1 opacity-75" />
                  </div>
                ) : (
                  /* Smoke puff */
                  <div className="w-2 h-4 text-slate-400 font-bold text-xs select-none animate-pulse">
                    💨
                  </div>
                )}
                {/* Candle Wick */}
                <div className="w-0.5 h-2 bg-slate-800" />
                {/* Candle body */}
                <div className={`w-3.5 h-12 rounded-t-sm shadow-xs ${
                  idx === 0 ? 'bg-gradient-to-b from-pink-300 to-pink-400' :
                  idx === 1 ? 'bg-gradient-to-b from-amber-200 to-amber-300' :
                  'bg-gradient-to-b from-rose-300 to-rose-400'
                }`} />
              </div>
            ))}
          </div>

          {/* Tier 1 (Top Layer) */}
          <div className="relative w-36 h-14 bg-gradient-to-r from-pink-200 via-rose-100 to-pink-200 rounded-t-2xl border-b-4 border-pink-300 shadow-md flex items-center justify-center">
            {/* Strawberries & Cream drops */}
            <div className="absolute -top-2 flex gap-4">
              <span className="text-sm select-none">🍓</span>
              <span className="text-xs select-none">🤍</span>
              <span className="text-sm select-none">🍓</span>
            </div>
            <span className="text-xs font-bold text-pink-700 tracking-wider">08 / 11</span>
          </div>

          {/* Tier 2 (Middle Layer) */}
          <div className="relative w-48 h-16 bg-gradient-to-r from-amber-100 via-yellow-50 to-amber-100 rounded-t-xl border-b-4 border-amber-200 shadow-md flex items-center justify-center">
            <span className="font-handwriting text-lg font-bold text-rose-600">
              Happy Birthday Cô Phúc
            </span>
          </div>

          {/* Tier 3 (Bottom Layer) */}
          <div className="relative w-60 h-16 bg-gradient-to-r from-pink-300 via-rose-200 to-pink-300 rounded-t-xl border-b-4 border-pink-400 shadow-lg flex items-center justify-around px-4">
            <span className="text-xs select-none">🌸</span>
            <span className="text-xs select-none">✨</span>
            <span className="text-xs font-bold text-rose-800">Tuổi Mới Rực Rỡ</span>
            <span className="text-xs select-none">✨</span>
            <span className="text-xs select-none">🌸</span>
          </div>

          {/* Cake Stand / Plate */}
          <div className="w-68 h-4 bg-gradient-to-r from-slate-200 via-white to-slate-200 rounded-full shadow-md border border-slate-300" />
        </div>

        {/* State Banner */}
        {wishMade ? (
          <div className="my-6 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl max-w-lg mx-auto animate-in fade-in zoom-in-95">
            <p className="text-emerald-800 font-bold text-base sm:text-lg">
              ✨ Ước nguyện đã được gửi gắm tới các vì sao!
            </p>
            <p className="text-emerald-700 text-xs sm:text-sm mt-1">
              Chúc mọi điều ước của cô Phúc trong sinh nhật năm nay đều sẽ sớm trở thành hiện thực rực rỡ nhất!
            </p>
          </div>
        ) : (
          <p className="text-xs text-slate-500 my-4 italic">
            {candlesLit ? 'Ngọn nến đang cháy sáng lung linh... Nhấn nút thổi nến bên dưới!' : 'Nến đã tắt!'}
          </p>
        )}

        {/* Control Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          {candlesLit ? (
            <button
              type="button"
              onClick={handleBlowCandles}
              className="px-6 py-2.5 rounded-full text-sm font-bold text-white bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 hover:from-rose-600 hover:to-pink-600 shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Wind className="w-4 h-4" />
              <span>Thổi Nến Ngay</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleRelight}
              className="px-6 py-2.5 rounded-full text-sm font-bold text-amber-900 bg-amber-200 hover:bg-amber-300 shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Thắp Sáng Lại Nến</span>
            </button>
          )}

          <button
            type="button"
            onClick={onPlayMelody}
            className={`px-5 py-2.5 rounded-full text-sm font-semibold flex items-center gap-2 transition-all shadow-xs ${
              isPlayingMusic
                ? 'bg-pink-600 text-white'
                : 'bg-white text-slate-700 border border-slate-200 hover:border-pink-300 hover:text-pink-600'
            }`}
          >
            <Music className="w-4 h-4 text-pink-500" />
            <span>{isPlayingMusic ? 'Dừng Nhạc' : 'Bật Nhạc Sinh Nhật'}</span>
          </button>
        </div>
      </div>
    </section>
  );
};
