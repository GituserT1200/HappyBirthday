import React from 'react';
import { Heart, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="mt-20 border-t border-pink-200/80 bg-gradient-to-b from-transparent to-pink-100/50 py-12 px-4">
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-pink-600">
          <Heart className="w-5 h-5 fill-pink-500 text-pink-500 animate-pulse" />
          <span className="font-bold text-lg">Mừng Sinh Nhật Cô Phúc · 08/11</span>
          <Heart className="w-5 h-5 fill-pink-500 text-pink-500 animate-pulse" />
        </div>

        <p className="text-slate-600 text-sm max-w-md mx-auto leading-relaxed">
          Kính chúc Cô Phúc luôn tràn ngập niềm vui, an khang, hạnh phúc bên gia đình và tiếp tục chắp cánh cho bao ước mơ thế hệ học trò bay cao!
        </p>

        <div className="pt-2">
          <button
            type="button"
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold text-slate-700 bg-white border border-pink-200 hover:bg-pink-50 hover:text-pink-600 transition-colors shadow-2xs cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            <span>Lên đầu trang</span>
          </button>
        </div>

        <div className="text-[12px] text-slate-400 pt-4">
          Một trang web kỷ niệm ấm áp dành tặng cô giáo kính yêu.
        </div>
      </div>
    </footer>
  );
};
