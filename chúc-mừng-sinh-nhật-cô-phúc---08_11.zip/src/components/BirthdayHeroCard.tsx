import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Mail, MailOpen, Cake, Music, Gift, Heart, Sparkles, Star } from 'lucide-react';
import { sound } from '../utils/soundEffects';

interface BirthdayHeroCardProps {
  onScrollToGift: () => void;
  onPlayMelody: () => void;
  isPlayingMusic: boolean;
}

export const BirthdayHeroCard: React.FC<BirthdayHeroCardProps> = ({
  onScrollToGift,
  onPlayMelody,
  isPlayingMusic,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleCard = () => {
    if (!isOpen) {
      sound.playSparkle();
      confetti({
        particleCount: 70,
        spread: 80,
        origin: { y: 0.4 },
        colors: ['#f472b6', '#fb7185', '#f59e0b', '#ec4899', '#fbcfe8'],
      });
    }
    setIsOpen(!isOpen);
  };

  return (
    <section id="thiep-chuc" className="py-12 sm:py-16 px-4 max-w-4xl mx-auto">
      {/* Decorative intro banner */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 text-sm font-semibold text-pink-700 bg-pink-100/80 px-4 py-1.5 rounded-full mb-3 shadow-xs">
          <Sparkles className="w-4 h-4 text-pink-500" />
          <span>Ngày Đặc Biệt · 08 Tháng 11</span>
          <Sparkles className="w-4 h-4 text-pink-500" />
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight text-balance">
          Mừng Sinh Nhật <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500">Cô Phúc</span>!
        </h1>
        <p className="mt-2 text-slate-600 text-base sm:text-lg max-w-xl mx-auto">
          Một món quà kỷ niệm nhỏ bé chứa chan muôn vàn tình cảm, lòng biết ơn và những lời chúc ngọt ngào nhất.
        </p>
      </div>

      {/* Interactive Birthday Card Container */}
      <div className="perspective-1000 max-w-2xl mx-auto">
        {!isOpen ? (
          /* CLOSED ENVELOPE STATE */
          <button
            type="button"
            onClick={handleToggleCard}
            className="w-full text-left group relative cursor-pointer bg-gradient-to-br from-pink-100 via-rose-50 to-amber-100/70 rounded-3xl p-8 sm:p-12 shadow-xl border-2 border-pink-200/80 hover:shadow-2xl hover:border-pink-300 transition-all duration-300 transform hover:-translate-y-1.5 overflow-hidden"
            aria-label="Nhấn để mở thiệp chúc mừng sinh nhật Cô Phúc"
          >
            {/* Top decorative envelope fold line */}
            <div className="absolute top-0 inset-x-0 h-16 bg-gradient-to-b from-pink-200/40 to-transparent pointer-events-none" />

            {/* Corner flowers */}
            <span className="absolute top-4 left-4 text-2xl select-none opacity-80 group-hover:scale-110 transition-transform">🌸</span>
            <span className="absolute top-4 right-4 text-2xl select-none opacity-80 group-hover:scale-110 transition-transform">🌷</span>
            <span className="absolute bottom-4 left-4 text-2xl select-none opacity-80 group-hover:scale-110 transition-transform">✨</span>
            <span className="absolute bottom-4 right-4 text-2xl select-none opacity-80 group-hover:scale-110 transition-transform">🍰</span>

            <div className="flex flex-col items-center text-center space-y-5">
              {/* Golden Wax Seal */}
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-200 p-1 shadow-lg group-hover:rotate-6 transition-transform flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-rose-500 to-pink-600 flex flex-col items-center justify-center text-white border-2 border-amber-300/60 shadow-inner">
                  <Heart className="w-6 h-6 fill-white text-white drop-shadow-xs" />
                  <span className="text-[10px] font-bold tracking-wider mt-0.5">08 / 11</span>
                </div>
              </div>

              <div>
                <span className="text-xs uppercase tracking-widest text-pink-600 font-bold block mb-1">
                  Thiệp Mừng Kính Gửi
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold text-slate-800">
                  Cô Phúc Yêu Quý
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  Bên trong có lời chúc và món quà bất ngờ gửi tới cô
                </p>
              </div>

              <div className="pt-2">
                <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-pink-500 to-rose-500 group-hover:from-pink-600 group-hover:to-rose-600 shadow-md group-hover:shadow-lg transition-all">
                  <Mail className="w-4 h-4" />
                  <span>Nhấn Để Mở Thiệp</span>
                </span>
              </div>
            </div>
          </button>
        ) : (
          /* OPENED PARCHMENT CARD STATE */
          <div className="relative bg-gradient-to-b from-amber-50/90 via-white to-pink-50/80 rounded-3xl p-6 sm:p-10 shadow-2xl border-2 border-pink-200 animate-in fade-in zoom-in-95 duration-500">
            {/* Soft decorative stamps and icons */}
            <div className="flex items-center justify-between border-b border-pink-200/70 pb-4 mb-6">
              <div className="flex items-center gap-2 text-xs font-semibold text-pink-700 bg-pink-100/70 px-3 py-1 rounded-full">
                <Star className="w-3.5 h-3.5 fill-pink-500 text-pink-500" />
                <span>Sinh Nhật 08/11 · Dành tặng Cô Phúc</span>
              </div>
              <button
                type="button"
                onClick={handleToggleCard}
                className="text-xs font-medium text-slate-500 hover:text-pink-600 flex items-center gap-1 transition-colors px-2.5 py-1 rounded-lg hover:bg-pink-50"
              >
                <MailOpen className="w-3.5 h-3.5" />
                <span>Gấp thiệp lại</span>
              </button>
            </div>

            {/* Personalized greeting letter */}
            <div className="space-y-6 text-center sm:text-left">
              <div className="text-center">
                <span className="font-handwriting text-2xl text-pink-600 font-bold block mb-1">
                  Happy Birthday To You!
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  Kính Gửi Cô Phúc Thân Thương,
                </h3>
              </div>

              {/* Main Prominent Wish from document */}
              <div className="bg-gradient-to-r from-pink-100/80 via-rose-50 to-amber-100/80 rounded-2xl p-6 sm:p-8 border border-pink-200/90 shadow-sm text-center relative overflow-hidden">
                <div className="text-xs uppercase tracking-widest text-pink-600 font-bold mb-2">
                  Lời Chúc Từ Tận Đáy Lòng
                </div>
                <p className="font-handwriting text-2xl sm:text-3xl font-bold text-rose-700 leading-relaxed text-balance">
                  &ldquo;Chúc cô sinh nhật vui vẻ, hạnh phúc bên gia đình.&rdquo;
                </p>
                <div className="mt-3 flex justify-center items-center gap-2 text-xs text-rose-500">
                  <Heart className="w-3.5 h-3.5 fill-rose-400 text-rose-400" />
                  <span>Tràn đầy niềm vui, sức khỏe và luôn an yên</span>
                  <Heart className="w-3.5 h-3.5 fill-rose-400 text-rose-400" />
                </div>
              </div>

              {/* Accompanying heartfelt paragraph */}
              <div className="text-slate-700 text-base sm:text-lg leading-relaxed bg-white/70 p-5 rounded-2xl border border-slate-100 shadow-2xs space-y-2">
                <p>
                  Nhân ngày đặc biệt hôm nay (8/11), chúng em xin gửi đến cô ngàn đóa hoa tươi thắm cùng những lời chúc tốt lành nhất. Cảm ơn cô vì đã luôn là người gieo mầm tri thức, mang đến sự ấm áp và truyền cảm hứng bất tận cho chúng em.
                </p>
                <p className="text-sm text-slate-500 italic">
                  Chúc cô tuổi mới luôn tươi trẻ, tràn đầy năng lượng và luôn mỉm cười rạng rỡ mỗi khi lên lớp!
                </p>
              </div>

              {/* Interactive Card Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={onPlayMelody}
                  className={`px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-xs ${
                    isPlayingMusic
                      ? 'bg-amber-500 text-white shadow-amber-200'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-pink-300 hover:text-pink-600'
                  }`}
                >
                  <Music className="w-4 h-4 text-pink-500" />
                  <span>{isPlayingMusic ? 'Đang phát giai điệu... 🎵' : 'Nghe Nhạc Sinh Nhật'}</span>
                </button>

                <button
                  type="button"
                  onClick={onScrollToGift}
                  className="px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-white bg-gradient-to-r from-pink-500 via-rose-500 to-pink-600 hover:from-pink-600 hover:to-rose-600 shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Gift className="w-4 h-4" />
                  <span>Mở Hộp Quà Tri Ân Bí Mật</span>
                </button>

                <a
                  href="#banh-kem"
                  className="px-4 py-2.5 rounded-xl font-semibold text-xs sm:text-sm text-slate-700 bg-white border border-slate-200 hover:text-pink-600 hover:border-pink-300 transition-all flex items-center gap-2"
                >
                  <Cake className="w-4 h-4 text-amber-500" />
                  <span>Thổi Nến Cùng Cô</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
