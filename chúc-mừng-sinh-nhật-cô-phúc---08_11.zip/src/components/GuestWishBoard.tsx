import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Send, Heart, MessageSquareHeart, CheckCircle2, AlertCircle } from 'lucide-react';
import { WishEntry, validateWish, INITIAL_WISHES } from '../utils/birthdayLogic';
import { sound } from '../utils/soundEffects';

const STORAGE_KEY = 'co_phuc_birthday_wishes_v1';

const QUICK_TAGS = [
  '🌸 Chúc cô luôn bình an & trẻ đẹp',
  '💖 Hạnh phúc ấm áp bên gia đình',
  '✨ Vạn sự như ý & ngập tràn niềm vui',
  '🙏 Tri ân và cảm ơn cô vì tất cả!',
];

export const GuestWishBoard: React.FC = () => {
  const [wishes, setWishes] = useState<WishEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return INITIAL_WISHES;
  });

  const [senderName, setSenderName] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(wishes));
    } catch {
      // ignore
    }
  }, [wishes]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateWish(senderName, message);
    if (!validation.isValid) {
      setError(validation.error || 'Vui lòng kiểm tra lại thông tin');
      return;
    }

    const newWish: WishEntry = {
      id: `wish-${Date.now()}`,
      senderName: senderName.trim(),
      message: message.trim(),
      timestamp: Date.now(),
      likes: 1,
    };

    setWishes([newWish, ...wishes]);
    setSenderName('');
    setMessage('');
    setError(null);
    setSuccessMessage('Lời chúc của bạn đã được gửi thành công đến Cô Phúc! 💖');

    sound.playSparkle();
    confetti({
      particleCount: 80,
      spread: 75,
      origin: { y: 0.6 },
      colors: ['#ec4899', '#f43f5e', '#f59e0b', '#10b981'],
    });

    setTimeout(() => {
      setSuccessMessage(null);
    }, 4500);
  };

  const handleLike = (id: string) => {
    sound.playHeartSound();
    setWishes((prev) =>
      prev.map((w) => (w.id === id ? { ...w, likes: w.likes + 1 } : w))
    );
  };

  const handleAddQuickTag = (tag: string) => {
    sound.playHeartSound();
    setMessage((prev) => {
      if (!prev) return tag;
      return `${prev} ${tag}`;
    });
  };

  return (
    <section id="loi-chuc" className="py-16 sm:py-20 px-4 max-w-5xl mx-auto">
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 text-sm font-semibold text-pink-700 bg-pink-100/80 px-4 py-1.5 rounded-full mb-3 shadow-xs">
          <MessageSquareHeart className="w-4 h-4 text-pink-500" />
          <span>Lưu Bút & Lời Chúc Yêu Thương</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
          Gửi Lời Chúc Ngược Lại Cho Cô Phúc
        </h2>
        <p className="mt-2 text-slate-600 text-base max-w-xl mx-auto">
          Cùng để lại những dòng nhắn gửi thân thương, những kỷ niệm khó quên và lời cầu chúc tuyệt vời nhất dành tặng cô.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left column: Wish form */}
        <div className="lg:col-span-5 bg-white/95 backdrop-blur-md rounded-3xl p-6 sm:p-8 border border-pink-200/90 shadow-xl">
          <h3 className="text-xl font-bold text-slate-900 mb-1 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
            <span>Viết Lời Chúc Mới</span>
          </h3>
          <p className="text-xs text-slate-500 mb-5">
            Lời chúc của bạn sẽ xuất hiện ngay trên bảng tin lưu bút!
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="senderName" className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Tên / Danh xưng của bạn
              </label>
              <input
                id="senderName"
                type="text"
                value={senderName}
                onChange={(e) => {
                  setSenderName(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Ví dụ: Học trò cũ, Nam Anh, Lớp 12A..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none text-sm transition-all text-slate-800"
                maxLength={50}
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Lời chúc gửi tới Cô Phúc
              </label>
              <textarea
                id="message"
                rows={4}
                value={message}
                onChange={(e) => {
                  setMessage(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Gửi gắm những lời chúc ngọt ngào, ấm áp nhất tới cô..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none text-sm transition-all text-slate-800 resize-none"
                maxLength={500}
              />
              <div className="text-right text-[11px] text-slate-400 mt-1">
                {message.length}/500 ký tự
              </div>
            </div>

            {/* Quick Pick tags */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 block mb-1.5">
                Gợi ý nhanh (nhấn để thêm):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {QUICK_TAGS.map((tag, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleAddQuickTag(tag)}
                    className="text-xs px-2.5 py-1 rounded-lg bg-pink-50 text-pink-700 hover:bg-pink-100 border border-pink-100 transition-colors cursor-pointer text-left"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-rose-700 animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {successMessage && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-emerald-800 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 px-5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-pink-500 via-rose-500 to-pink-600 hover:from-pink-600 hover:to-rose-600 shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              <Send className="w-4 h-4" />
              <span>Gửi Lời Chúc Ngay</span>
            </button>
          </form>
        </div>

        {/* Right column: Wish list board */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-pink-200/60">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Heart className="w-4 h-4 fill-pink-500 text-pink-500" />
              <span>Bảng Lưu Bút Chúc Mừng ({wishes.length})</span>
            </h3>
            <span className="text-xs text-slate-500">
              Cập nhật tức thì
            </span>
          </div>

          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
            {wishes.map((w) => (
              <div
                key={w.id}
                className="p-5 rounded-2xl bg-white/90 border border-pink-100 hover:border-pink-300 shadow-xs hover:shadow transition-all group"
              >
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
                      {w.senderName.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-bold text-sm text-slate-800">
                      {w.senderName}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    {new Date(w.timestamp).toLocaleDateString('vi-VN')}
                  </span>
                </div>

                <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line mb-3">
                  {w.message}
                </p>

                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => handleLike(w.id)}
                    aria-label={`Thả tim lời chúc của ${w.senderName}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 transition-colors cursor-pointer"
                  >
                    <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                    <span>{w.likes}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
