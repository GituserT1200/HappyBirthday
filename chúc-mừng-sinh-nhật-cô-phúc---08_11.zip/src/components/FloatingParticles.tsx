import React, { useEffect, useState } from 'react';

interface ClickHeart {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
}

const HEART_COLORS = ['#f472b6', '#fb7185', '#ec4899', '#f87171', '#fbbf24', '#a855f7'];

export const FloatingParticles: React.FC = () => {
  const [clickHearts, setClickHearts] = useState<ClickHeart[]>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      // Don't trigger if clicking on inputs or buttons where it might distract
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;

      const newHeart: ClickHeart = {
        id: Date.now() + Math.random(),
        x: e.clientX,
        y: e.clientY,
        color: HEART_COLORS[Math.floor(Math.random() * HEART_COLORS.length)],
        size: Math.floor(Math.random() * 12) + 16,
      };

      setClickHearts((prev) => [...prev.slice(-15), newHeart]);

      setTimeout(() => {
        setClickHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
      }, 1200);
    };

    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden" aria-hidden="true">
      {/* Background soft ambient floating orbs */}
      <div className="absolute top-12 left-10 w-72 h-72 rounded-full bg-pink-200/30 blur-3xl animate-soft-float" />
      <div className="absolute top-1/3 right-12 w-80 h-80 rounded-full bg-amber-200/30 blur-3xl animate-soft-float" style={{ animationDelay: '2s' }} />
      <div className="absolute bottom-20 left-1/4 w-96 h-96 rounded-full bg-rose-200/25 blur-3xl animate-soft-float" style={{ animationDelay: '1s' }} />

      {/* Floating gentle background icons */}
      <div className="absolute top-[18%] left-[8%] text-pink-300/40 text-3xl animate-soft-float select-none">🎈</div>
      <div className="absolute top-[28%] right-[10%] text-amber-300/40 text-2xl animate-soft-float select-none" style={{ animationDelay: '1.5s' }}>✨</div>
      <div className="absolute top-[55%] left-[5%] text-rose-300/40 text-2xl animate-soft-float select-none" style={{ animationDelay: '2.5s' }}>🌸</div>
      <div className="absolute top-[70%] right-[7%] text-pink-300/40 text-3xl animate-soft-float select-none" style={{ animationDelay: '0.8s' }}>💖</div>
      <div className="absolute top-[85%] left-[12%] text-amber-300/40 text-2xl animate-soft-float select-none" style={{ animationDelay: '3s' }}>🍰</div>

      {/* Interactive tap/click hearts */}
      {clickHearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none select-none transition-all duration-1000 ease-out"
          style={{
            left: `${heart.x}px`,
            top: `${heart.y}px`,
            animation: 'floatUpAndFade 1.2s forwards cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <svg
            width={heart.size}
            height={heart.size}
            viewBox="0 0 24 24"
            fill={heart.color}
            className="drop-shadow-sm"
          >
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
          </svg>
        </div>
      ))}

      <style>{`
        @keyframes floatUpAndFade {
          0% {
            transform: translate(-50%, -50%) scale(0.6) rotate(0deg);
            opacity: 1;
          }
          50% {
            transform: translate(-50%, -100%) scale(1.25) rotate(-10deg);
            opacity: 0.9;
          }
          100% {
            transform: translate(-50%, -160%) scale(1.5) rotate(15deg);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};
