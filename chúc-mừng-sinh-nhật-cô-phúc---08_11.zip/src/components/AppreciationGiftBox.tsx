import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Gift, Heart, Sparkles, Clock, BookOpen, Smile, HeartHandshake, Check, Copy } from 'lucide-react';
import { sound } from '../utils/soundEffects';
import { MEMORY_MILESTONES } from '../utils/birthdayLogic';

export const AppreciationGiftBox: React.FC = () => {
  const [isGiftOpen, setIsGiftOpen] = useState(false);
  const [selectedMilestone, setSelectedMilestone] = useState<string>('m1');
  const [copied, setCopied] = useState(false);
  const [hasLikedLetter, setHasLikedLetter] = useState(false);
  const [likeCount, setLikeCount] = useState(99);

  const gratitudeLetterText = `Em – không đại diện cho bất kỳ tổ chức hay cá nhân nào – chúc cô có một ngày hạnh phúc. Bên cạnh đó, em muốn gửi lời cảm ơn đến cô. Vì cô đã hỗ trợ, giúp đỡ em trong nhiều vấn đề, từ học tập cho đến những việc nhỏ nhặt trong cuộc sống hằng ngày trong hơn 3 năm qua. Cảm ơn cô vì những bài giảng tận tâm nhiệt huyết, cảm ơn cô vì những lần cùng lớp tham gia các hoạt động, cảm ơn cô vì những bài học rất sâu sắc về cuộc sống. Và cả những lần cô cùng cả lớp làm những điều mà cuộc sống không thể đem đến. Cuối cùng, em muốn chúc cô một ngày sinh nhật thật hạnh phúc bên gia đình.`;

  const handleOpenGift = () => {
    sound.playSparkle();
    sound.playPop();
    confetti({
      particleCount: 100,
      spread: 90,
      origin: { y: 0.5 },
      colors: ['#f43f5e', '#ec4899', '#f59e0b', '#8b5cf6', '#10b981'],
    });
    setIsGiftOpen(true);
  };

  const handleCopyLetter = () => {
    navigator.clipboard.writeText(gratitudeLetterText);
    setCopied(true);
    sound.playSparkle();
    setTimeout(() => setCopied(false), 2500);
  };

  const handleLikeLetter = () => {
    if (!hasLikedLetter) {
      setHasLikedLetter(true);
      setLikeCount((prev) => prev + 1);
      sound.playHeartSound();
      confetti({
        particleCount: 30,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#f43f5e', '#fb7185'],
      });
    }
  };

  return (
    <section id="tri-an" className="py-16 sm:py-20 px-4 max-w-5xl mx-auto">
      {/* Section Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 text-sm font-semibold text-rose-700 bg-rose-100/80 px-4 py-1.5 rounded-full mb-3 shadow-xs">
          <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
          <span>Tri Ân & Tình Cảm Suốt Hơn 3 Năm</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
          Hộp Quà Tri Ân Bí Mật & Những Kỷ Niệm Đáng Nhớ
        </h2>
        <p className="mt-3 text-slate-600 text-base sm:text-lg max-w-2xl mx-auto">
          Mỗi lời dặn dò, mỗi bài giảng và từng khoảnh khắc cô đồng hành cùng chúng em đều là những viên ngọc quý trong hành trang trưởng thành.
        </p>
      </div>

      {/* Secret Gift Box Interactive Card */}
      <div className="mb-16">
        {!isGiftOpen ? (
          <button
            type="button"
            onClick={handleOpenGift}
            className="w-full text-center group relative cursor-pointer max-w-xl mx-auto bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 rounded-3xl p-8 sm:p-12 border-2 border-dashed border-rose-300 hover:border-rose-400 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 block"
            aria-label="Nhấn để mở hộp quà bí mật tri ân cô Phúc"
          >
            {/* Animated 3D Gift Box Visual */}
            <div className="relative w-28 h-28 mx-auto mb-6">
              {/* Gift Ribbon Glow */}
              <div className="absolute inset-0 bg-rose-400/20 rounded-2xl filter blur-xl group-hover:bg-rose-400/40 transition-all" />
              {/* Gift box body */}
              <div className="relative w-full h-full bg-gradient-to-tr from-rose-500 to-pink-500 rounded-2xl shadow-xl flex items-center justify-center border-2 border-amber-200 group-hover:scale-105 transition-transform duration-300">
                {/* Horizontal & vertical golden ribbons */}
                <div className="absolute inset-x-0 h-4 bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-300 top-1/2 -translate-y-1/2 shadow-xs" />
                <div className="absolute inset-y-0 w-4 bg-gradient-to-b from-amber-300 via-yellow-200 to-amber-300 left-1/2 -translate-x-1/2 shadow-xs" />
                {/* Top Bow */}
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center justify-center">
                  <div className="w-8 h-8 rounded-full bg-amber-300 border-2 border-yellow-100 shadow-md flex items-center justify-center animate-bounce">
                    <Sparkles className="w-4 h-4 text-amber-800" />
                  </div>
                </div>
                <Gift className="w-10 h-10 text-white relative z-10 drop-shadow-sm group-hover:scale-110 transition-transform" />
              </div>
            </div>

            <h3 className="text-2xl font-bold text-slate-800 mb-2">
              Hộp Quà Tri Ân Bí Mật
            </h3>
            <p className="text-slate-600 text-sm sm:text-base max-w-md mx-auto mb-5">
              Chạm vào chiếc hộp để hé mở bức thư cảm ơn chân thành gửi đến Cô Phúc từ một người học trò!
            </p>

            <span className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-rose-500 to-pink-500 group-hover:from-rose-600 group-hover:to-pink-600 shadow-md transition-all">
              <Gift className="w-4 h-4" />
              <span>Chạm Để Mở Hộp Quà</span>
            </span>
          </button>
        ) : (
          /* Opened Gift with Letter */
          <div className="max-w-3xl mx-auto bg-gradient-to-b from-amber-50/60 via-white to-rose-50/50 rounded-3xl p-6 sm:p-10 shadow-2xl border border-rose-200 animate-in fade-in zoom-in-95 duration-500">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-rose-100 pb-5 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600 shadow-xs">
                  <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
                </div>
                <div>
                  <span className="text-xs uppercase tracking-wider text-rose-600 font-bold block">
                    Bức Thư Tri Ân
                  </span>
                  <h3 className="text-xl font-bold text-slate-900">
                    Gửi Cô Phúc Với Cả Tấm Lòng
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyLetter}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
                  title="Sao chép lời nhắn"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Đã sao chép' : 'Sao chép thư'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsGiftOpen(false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Đóng hộp
                </button>
              </div>
            </div>

            {/* Gratitude Letter Full Text Body */}
            <div className="bg-amber-50/70 rounded-2xl p-6 sm:p-8 border border-amber-200/60 shadow-inner relative">
              <span className="text-4xl text-amber-300 font-serif absolute top-3 left-4 select-none opacity-60">“</span>
              <p className="text-slate-800 text-base sm:text-lg leading-relaxed pt-3 px-2 sm:px-4 font-normal tracking-wide whitespace-pre-line text-balance">
                {gratitudeLetterText}
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-amber-200/50 pt-4 text-xs sm:text-sm text-slate-500">
                <span className="italic font-medium text-rose-700">
                  — Kính gửi Cô Phúc, ngày 8/11 yêu thương
                </span>
                <button
                  type="button"
                  onClick={handleLikeLetter}
                  className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full font-semibold transition-all ${
                    hasLikedLetter
                      ? 'bg-rose-500 text-white shadow-xs'
                      : 'bg-white text-rose-600 border border-rose-200 hover:bg-rose-50'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${hasLikedLetter ? 'fill-white' : 'fill-rose-500'}`} />
                  <span>{hasLikedLetter ? 'Đã gửi triệu trái tim' : 'Thả tim lá thư'} ({likeCount})</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4 Memory Milestones derived from the 3-year journey */}
      <div className="mt-12">
        <div className="text-center mb-8">
          <span className="text-xs uppercase tracking-widest text-slate-500 font-bold block mb-1">
            Chặng Đường Kỷ Niệm
          </span>
          <h3 className="text-2xl font-bold text-slate-900">
            Hơn 3 Năm Dìu Dắt & Đồng Hành Cùng Cô
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {MEMORY_MILESTONES.map((milestone) => {
            const isSelected = selectedMilestone === milestone.id;
            return (
              <div
                key={milestone.id}
                onClick={() => setSelectedMilestone(milestone.id)}
                className={`p-6 rounded-2xl border transition-all cursor-pointer relative ${
                  isSelected
                    ? 'bg-white border-rose-300 shadow-md ring-2 ring-rose-200/60'
                    : 'bg-white/80 border-slate-200/80 hover:border-rose-200 hover:bg-white shadow-xs hover:shadow'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    isSelected ? 'bg-rose-500 text-white shadow-sm' : 'bg-rose-50 text-rose-600'
                  }`}>
                    {milestone.id === 'm1' && <Clock className="w-6 h-6" />}
                    {milestone.id === 'm2' && <BookOpen className="w-6 h-6" />}
                    {milestone.id === 'm3' && <Smile className="w-6 h-6" />}
                    {milestone.id === 'm4' && <HeartHandshake className="w-6 h-6" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                        {milestone.tag}
                      </span>
                    </div>
                    <h4 className="text-lg font-bold text-slate-900 tracking-tight">
                      {milestone.title}
                    </h4>
                    <p className="text-xs text-slate-500 mb-2 font-medium">
                      {milestone.subtitle}
                    </p>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {milestone.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
