import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, RefreshCw, Star } from 'lucide-react';
import { LUCKY_WISH_CARDS } from '../utils/birthdayLogic';
import { sound } from '../utils/soundEffects';

export const LuckyWishDrawer: React.FC = () => {
  const [selectedCardIdx, setSelectedCardIdx] = useState<number | null>(null);

  const handlePickCard = (idx: number) => {
    setSelectedCardIdx(idx);
    sound.playSparkle();
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#f43f5e', '#fbbf24', '#38bdf8', '#ec4899'],
    });
  };

  const handleReset = () => {
    sound.playPop();
    setSelectedCardIdx(null);
  };

  return (
    <section className="py-14 px-4 max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-700 bg-purple-100/80 px-3.5 py-1 rounded-full mb-2">
          <Star className="w-3.5 h-3.5 fill-purple-500 text-purple-500" />
          <span>Mini-game May Mắn Đầu Tuổi Mới</span>
        </div>
        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          Bốc Quẻ Thông Điệp Yêu Thương
        </h3>
        <p className="text-sm text-slate-600 mt-1">
          Chọn một phong bao may mắn bất kỳ bên dưới để nhận lời chúc và năng lượng tích cực cho tuổi mới nhé cô!
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3.5 max-w-3xl mx-auto mb-6">
        {LUCKY_WISH_CARDS.map((card, idx) => {
          const isChosen = selectedCardIdx === idx;
          return (
            <button
              key={idx}
              type="button"
              onClick={() => handlePickCard(idx)}
              className={`p-4 rounded-2xl text-center border-2 transition-all flex flex-col items-center justify-center min-h-[120px] cursor-pointer group ${
                isChosen
                  ? 'bg-gradient-to-b from-rose-500 to-pink-600 border-amber-300 text-white shadow-lg scale-105'
                  : 'bg-white/90 border-pink-200 hover:border-pink-300 hover:bg-pink-50/50 shadow-xs hover:shadow hover:-translate-y-1'
              }`}
            >
              <span className="text-2xl mb-1 group-hover:scale-125 transition-transform">
                {isChosen ? '🎁' : '💌'}
              </span>
              <span className={`text-xs font-bold ${isChosen ? 'text-amber-100' : 'text-slate-700'}`}>
                Quẻ số {idx + 1}
              </span>
              <span className={`text-[10px] mt-0.5 ${isChosen ? 'text-pink-100' : 'text-slate-400'}`}>
                {isChosen ? 'Đã hé mở' : 'Chạm để mở'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Selected Card Reveal Display */}
      {selectedCardIdx !== null && (
        <div className="max-w-xl mx-auto bg-gradient-to-br from-pink-50 via-white to-amber-50 p-6 sm:p-8 rounded-3xl border border-pink-200 shadow-xl text-center animate-in fade-in zoom-in-95">
          <div className="w-12 h-12 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center mx-auto mb-3 shadow-xs">
            <Sparkles className="w-6 h-6" />
          </div>
          <h4 className="text-xl font-bold text-slate-900 mb-2">
            {LUCKY_WISH_CARDS[selectedCardIdx].title}
          </h4>
          <p className="text-slate-700 text-base leading-relaxed mb-5">
            {LUCKY_WISH_CARDS[selectedCardIdx].content}
          </p>
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-600 hover:text-pink-600 bg-slate-100 hover:bg-pink-50 rounded-xl transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Bốc quẻ may mắn khác</span>
          </button>
        </div>
      )}
    </section>
  );
};
