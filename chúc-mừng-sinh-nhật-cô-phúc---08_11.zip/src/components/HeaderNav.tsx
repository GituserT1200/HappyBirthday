import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Volume2, VolumeX, Sparkles, Heart } from 'lucide-react';
import { sound } from '../utils/soundEffects';

interface HeaderNavProps {
  onTriggerConfetti?: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = () => {
  const [isMuted, setIsMuted] = useState(sound.isMuted);

  const handleToggleSound = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      sound.playSparkle();
    }
  };

  const handleConfettiBurst = () => {
    sound.playPop();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.2 },
      colors: ['#f472b6', '#fb7185', '#f59e0b', '#ec4899', '#38bdf8', '#a855f7'],
    });
  };

  return (
    <header className="sticky top-0 z-30 bg-amber-50/90 backdrop-blur-md border-b border-pink-100/80 transition-all">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#thiep-chuc"
          className="text-lg font-bold tracking-tight text-pink-700 hover:text-pink-800 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 shadow-xs">
            <Heart className="w-4 h-4 fill-pink-500 text-pink-500" />
          </span>
          <span>Sinh Nhật Cô Phúc</span>
        </a>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <a
            href="#thiep-chuc"
            className="hover:text-pink-600 transition-colors whitespace-nowrap shrink-0"
          >
            Thiệp Chúc Mừng
          </a>
          <a
            href="#tri-an"
            className="hover:text-pink-600 transition-colors whitespace-nowrap shrink-0"
          >
            Tri Ân 3 Năm
          </a>
          <a
            href="#banh-kem"
            className="hover:text-pink-600 transition-colors whitespace-nowrap shrink-0"
          >
            Bánh Kem & Thổi Nến
          </a>
          <a
            href="#loi-chuc"
            className="hover:text-pink-600 transition-colors whitespace-nowrap shrink-0"
          >
            Gửi Lời Chúc
          </a>
        </nav>

        {/* Zone 3: 1 primary action area */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleToggleSound}
            title={isMuted ? 'Bật âm thanh hiệu ứng' : 'Tắt âm thanh hiệu ứng'}
            aria-label={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
            className="p-2 text-pink-700 bg-pink-100/70 hover:bg-pink-200/80 rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-pink-500"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={handleConfettiBurst}
            aria-label="Thả pháo hoa chúc mừng"
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 rounded-full shadow-xs hover:shadow transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Thả Pháo Hoa</span>
          </button>
        </div>
      </div>
    </header>
  );
};
